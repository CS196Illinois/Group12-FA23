+----------+-------------------+
| smiths   | R Documentation   |
+----------+-------------------+

Demo data describing the Smiths.
--------------------------------

Description
~~~~~~~~~~~

A small demo dataset describing John and Mary Smith. Used in the
introductory vignette.

Usage
~~~~~

::

    data(smiths)

Format
~~~~~~

A data frame with 2 rows and 5 variables
